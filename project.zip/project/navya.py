Python 3.11.2 (tags/v3.11.2:878ead1, Feb  7 2023, 16:38:35) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\User\Desktop\programs python\project in scholastic achievement.py
15
enter student name:sruthi
enter roll number:09
enter marks:40 50 60
enter student name:navya
enter roll number:13
enter marks:45 55 60
enter student name:janu
enter roll number:02
enter marks:55 45 64
enter student name:hema
enter roll number:21
enter marks:44 53 45
enter student name:jyothi
enter roll number:22
enter marks:53 43 40
enter student name:rahithya
enter roll number:29
enter marks:40 50 60
enter student name:deepika
enter roll number:17
enter marks:30 40 50
enter student name:varsha
enter roll number:20
enter marks:90 60 70
enter student name:harshi
enter roll number:38
enter marks:60 59 39
enter student name:swathi
enter roll number:50
enter marks:60 70 80
enter student name:divya
enter roll number:46
enter marks:60 70 50
enter student name:hanvi
enter roll number:07
enter marks:90 60 80
enter student name:harika
enter roll number:39
enter marks:70 79 80
enter student name:rohini
enter roll number:90
enter marks:78 80 99
enter student name:neha
enter roll number:89
enter marks:80 80 70
        name  rollnumber         marks  total
0     sruthi           9  [40, 50, 60]    150
1      navya          13  [45, 55, 60]    160
2       janu           2  [55, 45, 64]    164
3       hema          21  [44, 53, 45]    142
4     jyothi          22  [53, 43, 40]    136
5   rahithya          29  [40, 50, 60]    150
6    deepika          17  [30, 40, 50]    120
7     varsha          20  [90, 60, 70]    220
8     harshi          38  [60, 59, 39]    158
9     swathi          50  [60, 70, 80]    210
10     divya          46  [60, 70, 50]    180
11     hanvi           7  [90, 60, 80]    230
12    harika          39  [70, 79, 80]    229
13    rohini          90  [78, 80, 99]    257
14      neha          89  [80, 80, 70]    230
max total=: 257
min total=: 120
sort total=: [120, 136, 142, 150, 150, 158, 160, 164, 180, 210, 220, 229, 230, 230, 257]
{160, 257, 164, 229, 230, 136, 142, 210, 180, 150, 120, 220, 158}
maximum score of student1: 60
minimum score of student1: 40
total score of student1: 150
average score of student1: 50.0
sort of all marks 1: [40, 50, 60]
score of each subject without duplicates: {40, 50, 60}
maximum score of student2: 60
minimum score of student2: 45
total score of student2: 160
average score of student2: 53.333333333333336
sort of all marks 2: [45, 55, 60]
score of each subject without duplicates: {60, 45, 55}
maximum score of student3: 64
minimum score of student3: 45
total score of student3: 164
average score of student3: 54.666666666666664
sort of all marks 3: [45, 55, 64]
score of each subject without duplicates: {64, 45, 55}
maximum score of student4: 53
minimum score of student4: 44
total score of student4: 142
average score of student4: 47.333333333333336
sort of all marks 4: [44, 45, 53]
score of each subject without duplicates: {53, 44, 45}
maximum score of student5: 53
minimum score of student5: 40
total score of student5: 136
average score of student5: 45.333333333333336
sort of all marks 5: [40, 43, 53]
score of each subject without duplicates: {40, 43, 53}
maximum score of student6: 60
minimum score of student6: 40
total score of student6: 150
average score of student6: 50.0
sort of all marks 6: [40, 50, 60]
score of each subject without duplicates: {40, 50, 60}
maximum score of student7: 50
minimum score of student7: 30
total score of student7: 120
average score of student7: 40.0
sort of all marks 7: [30, 40, 50]
score of each subject without duplicates: {40, 50, 30}
maximum score of student8: 90
minimum score of student8: 60
total score of student8: 220
average score of student8: 73.33333333333333
sort of all marks 8: [60, 70, 90]
score of each subject without duplicates: {90, 60, 70}
maximum score of student9: 60
minimum score of student9: 39
total score of student9: 158
average score of student9: 52.666666666666664
sort of all marks 9: [39, 59, 60]
score of each subject without duplicates: {59, 60, 39}
maximum score of student10: 80
minimum score of student10: 60
total score of student10: 210
average score of student10: 70.0
sort of all marks 10: [60, 70, 80]
score of each subject without duplicates: {80, 60, 70}
maximum score of student11: 70
minimum score of student11: 50
total score of student11: 180
average score of student11: 60.0
sort of all marks 11: [50, 60, 70]
score of each subject without duplicates: {50, 60, 70}
maximum score of student12: 90
minimum score of student12: 60
total score of student12: 230
average score of student12: 76.66666666666667
sort of all marks 12: [60, 80, 90]
score of each subject without duplicates: {80, 90, 60}
maximum score of student13: 80
minimum score of student13: 70
total score of student13: 229
average score of student13: 76.33333333333333
sort of all marks 13: [70, 79, 80]
score of each subject without duplicates: {80, 70, 79}
maximum score of student14: 99
minimum score of student14: 78
total score of student14: 257
average score of student14: 85.66666666666667
sort of all marks 14: [78, 80, 99]
score of each subject without duplicates: {80, 99, 78}
maximum score of student15: 80
minimum score of student15: 70
total score of student15: 230
average score of student15: 76.66666666666667
sort of all marks 15: [70, 80, 80]
score of each subject without duplicates: {80, 70}
maximum marks in subject 1: 78
maximum marks in subject 2: 80
maximum marks in subject 3: 99
